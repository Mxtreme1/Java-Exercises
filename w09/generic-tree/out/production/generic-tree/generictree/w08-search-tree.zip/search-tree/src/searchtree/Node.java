package searchtree;

/**
 * Created by thiemann on 03.07.17.
 */
public class Node implements Tree {
    private final Tree left;
    private final int v;
    private final Tree right;

    public Node(Tree left, int v, Tree right) {
        this.left = left;
        this.v = v;
        this.right = right;
    }

    @Override
    public Tree add(int i) {
        if (i == v) {
            return this; // i is present, return unchanged
        }
        if (i < v) {
            Tree newl = left.add(i);
            return new Node(newl, v, right);
        } else {
            Tree newr = right.add(i);
            return new Node(left, v, newr);
        }
    }

    @Override
    public boolean contains(int i) {
        if (i == v) {
            return true;
        }
        if (i < v) {
            return left.contains(i);
        } else {
            return right.contains(i);
        }
    }

    // not proper object-oriented style
    public boolean alternativeContains(int i) {
        Node node = this;
        Tree t;
        if (i == v) {
            return true;
        }
        if (i < v) {
            t = node.left;
        } else {
            t = node.right;
        }
        //  Tree t may be a Node or Leaf
        // incomplete
        return false;
    }

    @Override
    public int size() {
        int sizel = left.size();
        int sizer = right.size();
        return 1 + sizel + sizer;
    }

    @Override
    public String elementsAsString() {
        String elemsl = left.elementsAsString();
        String elemsr = right.elementsAsString();
        String result = elemsl;
        if (!result.equals("")) {
            result = result + ", ";
        }
        result = result + v;
        if (!elemsr.equals("")) {
            result = result + ", " + elemsr;
        }
        return result;
    }
}
